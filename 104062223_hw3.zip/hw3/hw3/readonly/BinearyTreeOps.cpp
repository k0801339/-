//===================THE-EDITS-OF-THIS-FILE-WILL-BE-DISCARDED===================

#include "BinearyTreeOps.h"

Node* BinearyTreeOps::constructTree(Node *root, std::string treeStr)const
{
    throw "[Undefined BinearyTreeOps::constructTree]";
}

Node* BinearyTreeOps::deleteTree(Node *root)const
{
    throw "[Undefined BinearyTreeOps::deleteTree]";
}

int BinearyTreeOps::treeHeight(const Node *root)const
{
    throw "[Undefined BinearyTreeOps::treeHeight]";
}

int BinearyTreeOps::treeWeight(const Node *root)const
{
    throw "[Undefined BinearyTreeOps::treeWeight]";
}

int BinearyTreeOps::leafNum(const Node *root)const
{
    throw "[Undefined BinearyTreeOps::leafNum]";
}

int BinearyTreeOps::maxPathWeight(const Node *root)const
{
    throw "[Undefined BinearyTreeOps::mexPathWeight]";
}

//===================THE-EDITS-OF-THIS-FILE-WILL-BE-DISCARDED===================
