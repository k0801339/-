#include "Implement.h"
// add your code here
//------------------------------------------------------
void Implement::infix2Prefix(Expression &prefix, const Expression &infix){
	Stack<char> stack;
	//Expression ans;
	prefix.sz = infix.sz;
	prefix.data = new char[prefix.sz];
	int idx_a = 0, idx_b = infix.sz - 1;
	for(char x=infix.data[idx_b--];idx_b>=-1;x=infix.data[idx_b--]){
		if(x>='0'&&x<='9'){
			prefix.data[idx_a++] = x;
		}else if(x=='('){
			for(;stack.Top()!=')';stack.Pop()){
				prefix.data[idx_a++] = stack.Top();
			}
			stack.Pop();
		}else{
			for(;!stack.IsEmpty()&&isp(stack.Top())<icp(x);stack.Pop()){
				prefix.data[idx_a++] = stack.Top();
			}
			stack.Push(x);
		} 
	}
	for(;!stack.IsEmpty();stack.Pop()){
		prefix.data[idx_a++] = stack.Top();
	}
	prefix.sz = idx_a;
	for(int i=0;i<prefix.sz/2;i++){
		std::swap(prefix.data[i],prefix.data[prefix.sz-i-1]);
	}
	//prefix = ans;
}
void Implement::infix2Postfix(Expression &postfix, const Expression &infix){
	Stack<char> stack;
	//stack.Push('#');
	//Expression ans;
	postfix.sz = infix.sz;
	postfix.data = new char[postfix.sz];
	int idx_a = 0, idx_b = 0;
	for(char x=infix.data[idx_b++];idx_b<=infix.sz;x=infix.data[idx_b++]){
		if(x>='0'&&x<='9')	{
			postfix.data[idx_a++] = x;
		}
		else if(x==')'){
			for(;stack.Top()!='(';stack.Pop())
				postfix.data[idx_a++] = stack.Top();
			stack.Pop();
		}else{
			for(;!stack.IsEmpty()&&isp(stack.Top())<=icp(x);stack.Pop())
				postfix.data[idx_a++] = stack.Top();
			stack.Push(x);
		}
	}
	for(;!stack.IsEmpty();postfix.data[idx_a++]=stack.Top(),stack.Pop());
	//ans->data[idx_a] = '\n';
	//std::cout<<ans;
	postfix.sz = idx_a;
	//postfix = ans;
}
int Implement::evalPrefix(const Expression &prefix){
	Stack<int> stack;
	int idx=prefix.sz-1;
	int result = 0, int_x;
	int y;
	for(char x=prefix.data[idx--];idx>=-1;x=prefix.data[idx--]){
		if(x>='0'&&x<='9'){
			int_x = x - '0';
			stack.Push(int_x);
		}else{
			int a = stack.Top();	stack.Pop();
			int b = stack.Top();	stack.Pop();
			switch(x){
				case '+':
					result = a + b;
					break;
				case '-':
					result = a - b;
					break;
				case '*':
					result = a * b;
					break;
				case '/':
					result = a / b;
					break;
			}
			y = result;
			stack.Push(y);
		}
	}
	result = stack.Top();
	return result;
}
int Implement::evalPostfix(const Expression &postfix){
	Stack<int> stack;
	int idx=0;
	int result = 0, int_x = 0;
	int y;
	for(char x=postfix.data[idx++];idx<=postfix.sz;x=postfix.data[idx++]){
		if(x>='0'&&x<='9'){
			int_x = x - '0';
			stack.Push(int_x);
		}else{
			int b = stack.Top();	stack.Pop();
			int a = stack.Top();	stack.Pop();
			switch(x){
				case '+':
					result = a + b;
					break;
				case '-':
					result = a - b;
					break;
				case '*':
					result = a * b;
					break;
				case '/':
					result = a / b;
					break;
			}
			y = result;
			stack.Push(y);
		}
	}
	result = stack.Top();
	return result;
}

//------------------------------------------------------
