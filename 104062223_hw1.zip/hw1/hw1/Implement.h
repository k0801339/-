#ifndef Implement_h
#define Implement_h
#include <algorithm>
#include "readonly/ExpressionEval.h"

//typedef enum{L_paren='(',R_paren=')',ADD='+',SUB='-',MUL='*',DIV='/',END='#'} Token;
class Implement : public ExpressionEval
{
public:
    // add your code here
    //------------------------------------------------------
    void infix2Prefix(Expression &prefix, const Expression &infix);
    void infix2Postfix(Expression &postfix, const Expression &infix);
    int evalPrefix(const Expression &prefix);
    int evalPostfix(const Expression &postfix);
    /*char& NextToken(const Expression &e)
    {
    	static int idx = 0;
    	if(idx!=e.sz-1){
    		return e.data[idx++];
		}
	}*/
	int isp(char& top){
		if(top=='(' || top==')')	return 8;
		else if(top=='*'||top=='/')	return 2;
		else if(top=='+'||top=='-')	return 4;
	}
	int icp(char& top){
		if(top=='(' || top==')')	return 0;
		else if(top=='*'||top=='/')	return 2;
		else if(top=='+'||top=='-')	return 4;
	}
    
    //------------------------------------------------------
};
template<class T>
class Stack
{
	//friend class Implement;
public:
	Stack (int stackCapacity=2):capacity(stackCapacity) {
		if(capacity<1)	throw "Stack capacity must be >0";
		stack = new T[capacity];
		top = -1;
	}
	bool IsEmpty() const{
		return (top==-1);
	}
	T& Top() const{
		if(IsEmpty())	throw "Stack is empty";
		return stack[top];
	}
	void Push(const T& item){
		if(top==capacity-1){
			ChangeSize1D(stack,capacity,capacity*2);
			capacity *= 2;
		}
		stack[++top] = item;
	}
	void Pop(){
		if(IsEmpty())	throw "Stack is empty";
		stack[top--].~T();
	}
	void ChangeSize1D(T*& a, const int oldSize, const int newSize){
		if(newSize<0)	throw "New length must be >=0";
		T* tmp = new T[newSize];
		int num = oldSize>newSize?	newSize:oldSize;
		//memcpy(tmp,a,num);
		std::copy(a,a+num,tmp);
		delete [] a;
		a = tmp;
	}
	
private:
	T* stack;
	int top;
	int capacity;	
};

#endif
