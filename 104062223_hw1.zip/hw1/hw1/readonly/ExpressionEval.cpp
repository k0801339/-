//===================THE-EDITS-OF-THIS-FILE-WILL-BE-DISCARDED===================
#include "ExpressionEval.h"

void ExpressionEval::infix2Prefix(Expression&, const Expression&)
{
    throw "[Undefined ExpressionEval::infix2Prefix]";
}

void ExpressionEval::infix2Postfix(Expression&, const Expression&)
{
    throw "[Undefined ExpressionEval::infix2Postfix]";
}

int ExpressionEval::evalPrefix(const Expression&)
{
    throw "[Undefined ExpressionEval::evalPrefix]";
}

int ExpressionEval::evalPostfix(const Expression&)
{
    throw "[Undefined ExpressionEval::evalPostfix]";
}
//===================THE-EDITS-OF-THIS-FILE-WILL-BE-DISCARDED===================
